int main()
{
	printf("Hello");
	int adsf=0;
	double b=3.4;
	char c='w';
	adsf+=3;
	if ( !a==0&&b==0)

		printf("Hi");
	return 0;
}