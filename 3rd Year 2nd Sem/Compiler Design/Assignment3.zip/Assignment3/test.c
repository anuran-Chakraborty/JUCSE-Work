#include<stdio.h>

int main()
{
	int a=9;
	float c=8.89, d=0.45;

	if(a>0)
	{
		//Comment
		printf("Hi\n");
	}
	printf("Hello world");
	return 0;
}