int main()
{
	printf("Hello");
	int a=0;

	if ( a==0)
		
		printf("Hi");
	return 0;
}